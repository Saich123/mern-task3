function Compu1()
{
    return(
        <div>trail</div>
    )
}
export default Compu1;